<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatRoom extends Model
{
    protected $fillable = [
        'name',
        'type',
    ];

    public function users()
    {
        return $this->belongsToMany(User::class)
            ->withPivot('last_read_message_id')
            ->withTimestamps();
    }

    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    public function unreadCountForUser($userId)
    {
        $pivot = $this->users()->where('user_id', $userId)->first()?->pivot;
        $lastReadId = $pivot?->last_read_message_id;
        if ($lastReadId) {
            return $this->messages()->where('id', '>', $lastReadId)->where('user_id', '!=', $userId)->count();
        } else {
            return $this->messages()->where('user_id', '!=', $userId)->count();
        }
    }
}
