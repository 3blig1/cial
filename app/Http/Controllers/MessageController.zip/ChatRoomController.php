<?php

namespace App\Http\Controllers;

use App\Models\ChatRoom;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Message;



class ChatRoomController extends Controller
{
    public function index()
    {
        $userId = auth()->id();
        $chatRooms = ChatRoom::with('users')
            ->whereHas('users', function($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->get();
        $unreadCounts = [];
        foreach ($chatRooms as $room) {
            $unreadCounts[$room->id] = $room->unreadCountForUser($userId);
        }
        return view('chat.index', compact('chatRooms', 'unreadCounts'));
    }

    public function create()
    {
        $users = User::where('id', '!=', auth()->id())->get();
        return view('chat.create', compact('users'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'type' => 'required|in:group,private',
            'user_ids' => 'array',
        ]);
        $chatRoom = ChatRoom::create($data + ['user_id' => auth()->id()]);
        $userIds = $data['user_ids'] ?? [];
        $userIds[] = auth()->id(); // Ajoute le créateur
        $chatRoom->users()->sync(array_unique($userIds));
        return redirect()->route('chat.index')->with('success', 'Salon créé avec succès !');
    }

    public function show(ChatRoom $chatRoom)
    {
        $chatRoom->load(['users', 'messages.user', 'messages.attachment']);
        $user = auth()->user();
        $lastMessage = $chatRoom->messages()->latest('id')->first();
        // S’assurer que l’utilisateur est bien attaché au salon
        if (!$chatRoom->users->contains($user->id)) {
            $chatRoom->users()->attach($user->id);
            $chatRoom->load('users'); // refresh
        }
        if ($lastMessage) {
            $chatRoom->users()->updateExistingPivot($user->id, [
                'last_read_message_id' => $lastMessage->id
            ]);
        }
        return view('chat.show', [
            'chatRoom' => $chatRoom,
            'messages' => $chatRoom->messages,
        ]);
    }

    public function edit(ChatRoom $chatRoom)
    {
        $users = User::where('id', '!=', auth()->id())->get();
        $chatRoom->load('users');
        return view('chat.edit', compact('chatRoom', 'users'));
    }

    public function update(Request $request, ChatRoom $chatRoom)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'type' => 'required|in:group,private',
            'user_ids' => 'array',
        ]);
        $chatRoom->update($data);
        $chatRoom->users()->sync($data['user_ids'] ?? []);
        return redirect()->route('chat.index')->with('success', 'Salon modifié avec succès !');
    }

    public function destroy(ChatRoom $chatRoom)
    {
        $chatRoom->users()->detach();
        $chatRoom->delete();
        return redirect()->route('chat.index')->with('success', 'Salon supprimé avec succès !');
    }

    public static function getTotalUnreadMessages($userId)
    {
        $chatRooms = ChatRoom::with('users')
            ->whereHas('users', function($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->get();
        $total = 0;
        foreach ($chatRooms as $room) {
            $total += $room->unreadCountForUser($userId);
        }
        return $total;
    }
}
