@extends('layouts.app')

@section('content')
<div class="min-h-screen flex items-center justify-center bg-gray-50 py-8">
    <div class="w-full max-w-3xl bg-white rounded-2xl shadow-2xl flex flex-col h-[80vh] border border-green-400">
        <div class="flex items-center justify-between px-8 py-4 border-b border-green-200 bg-green-50 rounded-t-2xl">
            <div>
                <div class="text-2xl font-bold text-green-700">{{ $chatRoom->name }}</div>
                <div class="text-xs text-gray-500 mt-1">Membres : {{ $chatRoom->users->pluck('name')->join(', ') }}</div>
            </div>
            <a href="{{ route('chat.index') }}" class="bg-gray-200 text-gray-700 font-semibold px-4 py-2 rounded-full shadow hover:bg-gray-300 transition">Retour</a>
        </div>
        <div id="messages-list" class="flex-1 overflow-y-auto px-8 py-4 space-y-4 bg-gray-50">
            @foreach($messages as $message)
                <div class="flex {{ $message->user_id == auth()->id() ? 'justify-end' : 'justify-start' }}">
                    <div class="max-w-[70%] px-4 py-2 rounded-2xl shadow {{ $message->user_id == auth()->id() ? 'bg-green-200 text-green-900' : 'bg-white text-gray-800 border border-gray-200' }}">
                        <div class="text-sm font-semibold mb-1">{{ $message->user->name }}</div>
                        <div class="text-base">{!! nl2br(e($message->content)) !!}</div>
                        @if($message->attachment)
                            <div class="mt-2">
                                <a href="{{ route('messages.download', $message) }}" class="text-xs text-blue-600 underline">📎 {{ $message->attachment }}</a>
                            </div>
                        @endif
                        <div class="text-xs text-gray-400 mt-1 text-right">{{ $message->created_at->format('d/m/Y H:i') }}</div>
                    </div>
                </div>
            @endforeach
        </div>
        <form action="{{ route('chat.messages.store', $chatRoom) }}" method="POST" enctype="multipart/form-data" class="flex items-center gap-2 px-8 py-4 border-t border-green-200 bg-white rounded-b-2xl">
            @csrf
            <input type="text" name="content" class="flex-1 rounded-full border-gray-300 focus:border-green-500 focus:ring-green-500 shadow-sm px-4 py-2" placeholder="Écrire un message..." required autocomplete="off">
            <input type="file" name="attachment" class="hidden" id="attachment-input">
            <label for="attachment-input" class="cursor-pointer text-green-600 hover:text-green-800 text-xl" title="Joindre un fichier">📎</label>
            <button type="submit" class="bg-gradient-to-r from-green-400 to-green-700 text-white font-bold px-6 py-2 rounded-full shadow-lg hover:from-green-500 hover:to-green-800 transition">Envoyer</button>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
// Scroll auto en bas à l'ouverture
const messagesList = document.getElementById('messages-list');
if (messagesList) {
    messagesList.scrollTop = messagesList.scrollHeight;
}
</script>
@endsection
