

<?php $__env->startSection('title', 'Modifier un Élève'); ?>

<?php $__env->startSection('header-content'); ?>

        <a href="<?php echo e(route('students.index')); ?>" class="flex items-center gap-2 text-gray-600 hover:text-gray-900">
            <i class="ri-arrow-left-line"></i>
            <span>Retour à la liste</span>
        </a>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-semibold mb-8">Modifier l'Élève : <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h1>

<?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
        <strong class="font-bold">Oups !</strong>
        <span class="block sm:inline">Quelque chose s'est mal passé.</span>
        <ul class="mt-3 list-disc list-inside text-sm">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('students.update', $student)); ?>" method="POST" enctype="multipart/form-data" class="space-y-8">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="bg-white rounded-lg shadow-sm p-6 space-y-6">
        <div class="flex flex-col items-center">
            <div class="relative group">
                <div class="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
                    <img id="preview" src="<?php echo e($student->profile_photo_path ? asset('storage/' . $student->profile_photo_path) : ''); ?>" class="w-full h-full object-cover <?php echo e($student->profile_photo_path ? '' : 'hidden'); ?>" alt="Aperçu de la photo de profil">
                    <div id="icon-container" class="w-8 h-8 flex items-center justify-center text-gray-400 <?php echo e($student->profile_photo_path ? 'hidden' : 'flex'); ?>">
                        <i class="ri-user-line text-2xl"></i>
                    </div>
                </div>
                <label class="absolute bottom-0 right-0 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center cursor-pointer">
                    <input type="file" name="profile_photo" class="hidden" accept="image/*" onchange="previewImage(event)">
                    <div class="w-4 h-4 flex items-center justify-center text-gray-600">
                        <i class="ri-camera-line"></i>
                    </div>
                </label>
            </div>
            <p class="mt-2 text-sm text-gray-500">Photo de profil</p>
        </div>

        <div class="grid grid-cols-2 gap-6">
            <div>
                <label for="last_name" class="block text-sm font-medium text-gray-700 mb-1">Nom</label>
                <input type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', $student->last_name)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20" required>
            </div>
            <div>
                <label for="first_name" class="block text-sm font-medium text-gray-700 mb-1">Prénom</label>
                <input type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', $student->first_name)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20" required>
            </div>
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email', $student->email)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20" required>
            </div>
            <div>
                <label for="date_of_birth" class="block text-sm font-medium text-gray-700 mb-1">Date de naissance</label>
                <input type="date" name="date_of_birth" id="date_of_birth" value="<?php echo e(old('date_of_birth', $student->date_of_birth)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20" required>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-3">Niveau de langue</label>
            <div class="flex items-center gap-8">
                <?php $__currentLoopData = ['A1', 'A2', 'B1', 'B2', 'C1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="language_level" value="<?php echo e($level); ?>" <?php if(old('language_level', $student->language_level) == $level): ?> checked <?php endif; ?>>
                    <div class="custom-radio"></div>
                    <span class="text-sm"><?php echo e($level); ?></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm p-6 space-y-6">
        <h2 class="text-lg font-medium">Contact d'urgence</h2>
        <div class="grid grid-cols-2 gap-6">
            <div>
                <label for="emergency_contact_name" class="block text-sm font-medium text-gray-700 mb-1">Nom complet</label>
                <input type="text" name="emergency_contact_name" id="emergency_contact_name" value="<?php echo e(old('emergency_contact_name', $student->emergency_contact_name)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20">
            </div>
            <div>
                <label for="emergency_contact_relationship" class="block text-sm font-medium text-gray-700 mb-1">Relation</label>
                <input type="text" name="emergency_contact_relationship" id="emergency_contact_relationship" value="<?php echo e(old('emergency_contact_relationship', $student->emergency_contact_relationship)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20">
            </div>
            <div>
                <label for="emergency_contact_phone" class="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                <input type="tel" name="emergency_contact_phone" id="emergency_contact_phone" value="<?php echo e(old('emergency_contact_phone', $student->emergency_contact_phone)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20">
            </div>
            <div>
                <label for="emergency_contact_email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="emergency_contact_email" id="emergency_contact_email" value="<?php echo e(old('emergency_contact_email', $student->emergency_contact_email)); ?>" class="w-full px-3 py-2 border-none bg-gray-50 rounded focus:ring-2 focus:ring-primary/20">
            </div>
        </div>
    </div>

    <div class="flex justify-end">
        <button type="submit" class="px-6 py-2.5 bg-primary text-white font-medium rounded-button hover:bg-primary/90">Mettre à jour</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function previewImage(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById('preview');
                preview.src = e.target.result;
                preview.classList.remove('hidden');
                document.getElementById('icon-container').classList.add('hidden');
            }
            reader.readAsDataURL(file);
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\cial\resources\views/students/edit.blade.php ENDPATH**/ ?>