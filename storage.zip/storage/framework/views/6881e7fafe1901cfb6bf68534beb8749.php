

<?php $__env->startSection('title', 'Tableau de bord'); ?>

<?php $__env->startSection('header-content'); ?>
    <h1 class="text-xl font-semibold text-gray-800">Tableau de bord</h1>
    <div class="relative">
        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <i class="ri-search-line text-gray-400"></i>
        </div>
        <input type="text" placeholder="Rechercher..." class="pl-10 pr-4 py-2 w-96 rounded-lg border-none bg-gray-50 focus:ring-2 focus:ring-primary/20 text-sm">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Total Élèves</p>
                    <p class="text-2xl font-semibold mt-1"><?php echo e($totalStudents); ?></p>
                </div>
                <div class="w-10 h-10 flex items-center justify-center bg-primary/10 text-primary rounded-lg">
                    <i class="ri-user-line"></i>
                </div>
            </div>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Total Enseignants</p>
                    <p class="text-2xl font-semibold mt-1"><?php echo e($totalTeachers); ?></p>
                </div>
                <div class="w-10 h-10 flex items-center justify-center bg-primary/10 text-primary rounded-lg">
                    <i class="ri-team-line"></i>
                </div>
            </div>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Cours Actifs</p>
                    <p class="text-2xl font-semibold mt-1"><?php echo e($activeCoursesCount); ?></p>
                </div>
                <div class="w-10 h-10 flex items-center justify-center bg-primary/10 text-primary rounded-lg">
                    <i class="ri-book-open-line"></i>
                </div>
            </div>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Taux de Réussite</p>
                    <p class="text-2xl font-semibold mt-1">98%</p>
                </div>
                <div class="w-10 h-10 flex items-center justify-center bg-primary/10 text-primary rounded-lg">
                    <i class="ri-line-chart-line"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <h3 class="font-semibold mb-6">Progression des Inscriptions</h3>
            <div class="h-60" id="enrollmentChart"></div>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <h3 class="font-semibold mb-6">Distribution des Niveaux</h3>
            <div class="h-60" id="levelChart"></div>
        </div>
    </div>

    <div class="mt-6 bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b">
            <h3 class="font-semibold">Cours Récents</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="text-left text-sm text-gray-500">
                        <th class="px-6 py-4 font-medium">Cours</th>
                        <th class="px-6 py-4 font-medium">Enseignant</th>
                        <th class="px-6 py-4 font-medium">Niveau</th>
                        <th class="px-6 py-4 font-medium">Statut</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t">
                            <td class="px-6 py-4">
                                <a href="<?php echo e(route('courses.show', $course)); ?>" class="font-medium hover:text-primary"><?php echo e($course->title); ?></a>
                            </td>
                            <td class="px-6 py-4"><?php echo e($course->teacher->first_name ?? ''); ?> <?php echo e($course->teacher->last_name ?? ''); ?></td>
                            <td class="px-6 py-4"><span class="px-2 py-1 text-xs font-medium bg-blue-50 text-blue-700 rounded"><?php echo e($course->level); ?></span></td>
                            <td class="px-6 py-4">
                                <?php if(\Carbon\Carbon::parse($course->end_date)->isPast()): ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-700 rounded">Terminé</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-700 rounded">En cours</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-center px-6 py-4 text-gray-500">Aucun cours récent.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.5.0/echarts.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const enrollmentChart = echarts.init(document.getElementById('enrollmentChart'));
        enrollmentChart.setOption({
            tooltip: { trigger: 'axis' },
            xAxis: {
                type: 'category',
                data: <?php echo json_encode($enrollmentLabels, 15, 512) ?>,
                axisLine: { show: false },
                axisTick: { show: false },
            },
            yAxis: { type: 'value', show: false },
            series: [{
                data: <?php echo json_encode($enrollmentData, 15, 512) ?>,
                type: 'line',
                smooth: true,
                symbol: 'none',
                lineStyle: { color: '#4F46E5' },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(79, 70, 229, 0.2)'
                    }, {
                        offset: 1,
                        color: 'rgba(79, 70, 229, 0)'
                    }])
                }
            }]
        });

        const levelChart = echarts.init(document.getElementById('levelChart'));
        levelChart.setOption({
            tooltip: { trigger: 'item' },
            series: [{
                type: 'pie',
                radius: ['60%', '80%'],
                avoidLabelOverlap: false,
                data: <?php echo json_encode($levelChartData, 15, 512) ?>,
                label: { show: false },
                itemStyle: {
                    borderRadius: 4,
                    borderColor: '#fff',
                    borderWidth: 2
                }
            }]
        });

        window.addEventListener('resize', function() {
            enrollmentChart.resize();
            levelChart.resize();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\cial\resources\views/dashboard.blade.php ENDPATH**/ ?>