<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title', 'Academics &mdash; Website by Colorlib'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/fonts/flaticon/font/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/aos.css')); ?>">
    <link href="<?php echo e(asset('vendors/css/jquery.mb.YTPlayer.min.css')); ?>" media="all" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <div class="site-wrap">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- loader -->
    <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#51be78"/></svg></div>
    <script src="<?php echo e(asset('vendors/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery.stellar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery.easing.1.3.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery.sticky.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/jquery.mb.YTPlayer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/main.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\cial\resources\views/vitrine/layouts/app.blade.php ENDPATH**/ ?>